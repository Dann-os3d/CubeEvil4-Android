#!/usr/bin/env python3
"""Cross-checks the entity randomizer pool (port/whole/runtime/entity_random.h) against the game's own
tables: src/game/read.cpp EmFileTbl, src/game/em.cpp idName and config/G4BE08/modules/em<id>.
Usage: python3 tools/check_entity_pool.py [repo_root]      Exit code 1 on a real problem."""
import os, re, sys

root = sys.argv[1] if len(sys.argv) > 1 else os.getcwd()
read = open(os.path.join(root, "src/game/read.cpp"), encoding="utf8", errors="replace").read()
em = open(os.path.join(root, "src/game/em.cpp"), encoding="utf8", errors="replace").read()
hdr = open(os.path.join(root, "port/whole/runtime/entity_random.h"), encoding="utf8").read()
mods = set(os.listdir(os.path.join(root, "config/G4BE08/modules")))

tbl = re.search(r"ReadFile EmFileTbl\[64\] = \{(.*?)\};", read, re.S).group(1)
ents = [(int(a, 16), int(b, 16)) for a, b, _ in
        re.findall(r"\{\s*(0x[0-9A-Fa-f]+),\s*(0x[0-9A-Fa-f]+),\s*(\d)\s*\}", tbl)]
names = re.findall(r'"([^"]*)"', re.search(r"idName\[96\] = \{(.*?)\};", em, re.S).group(1))

def pool(defines):
    text = hdr
    arr = re.search(r"RE4_ACTOR_IDS\[\] = \{(.*?)\n\};", text, re.S).group(1)
    out, stack = [], [True]
    for line in arr.split("\n"):
        s = line.strip()
        m = re.match(r"#ifdef (\w+)", s)
        if m: stack.append(m.group(1) in defines); continue
        if s.startswith("#endif"): stack.pop(); continue
        if all(stack):
            out += [int(x, 16) for x in re.findall(r"0x[0-9A-Fa-f]+", re.sub(r"//.*", "", line))]
    return out

PLACEHOLDER = (0x18, 0x19)
bad = 0
default = pool(set())
full = pool({"RE4_RANDOM_INCLUDE_PROTECTED"})
print("pool (default): %d ids, (all tiers): %d ids" % (len(default), len(full)))
if len(set(full)) != len(full):
    print("ERROR duplicate ids in the pool"); bad += 1
files_seen = {}
for i in sorted(set(full)):
    mod = "em%02x" % i
    problems = []
    if mod not in mods: problems.append("no module " + mod)
    if ents[i] == PLACEHOLDER and i != 0x10: problems.append("EmFileTbl is the Ganado placeholder")
    if ents[i][0] in files_seen and i != 0x10:
        problems.append("shares file 0x%02x with 0x%02x" % (ents[i][0], files_seen[ents[i][0]]))
    files_seen.setdefault(ents[i][0], i)
    tier = "default" if i in default else "opt-in"
    print("  0x%02x %-18s %-7s %s" % (i, names[i] if i < len(names) else "?", tier,
                                        "OK" if not problems else "PROBLEM: " + "; ".join(problems)))
    bad += bool(problems)
print("\nids 0x10..0x3F that have a module but are NOT in the pool (and why):")
for i in range(0x10, 0x40):
    if i in full: continue
    has = ("em%02x" % i) in mods
    why = "module exists" if has else "no module of its own (placeholder %s)" % ("yes" if ents[i] == PLACEHOLDER else "no")
    print("  0x%02x %-18s %s" % (i, names[i] if i < len(names) else "?", why))
sys.exit(1 if bad else 0)
