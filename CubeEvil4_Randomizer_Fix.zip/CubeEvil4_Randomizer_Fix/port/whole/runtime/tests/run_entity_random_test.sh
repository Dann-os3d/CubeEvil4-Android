#!/bin/sh
set -eu
cxx=${CXX:-c++}
out="${TMPDIR:-/tmp}/re4_entity_random_test"
"$cxx" -std=c++11 -Wall -Wextra -Werror "$(dirname "$0")/entity_random_test.cpp" -o "$out"
"$out"
rm -f "$out"
echo "entity randomizer tests: PASS"
