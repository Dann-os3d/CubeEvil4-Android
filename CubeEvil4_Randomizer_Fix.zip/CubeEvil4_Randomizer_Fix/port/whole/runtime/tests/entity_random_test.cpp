#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include "../entity_random.h"

int main()
{
    // Ids that must never change: reserved/empty, ids without a module of their own (0x33, 0x37), the
    // merchant, Del Lago, Saddler, the giant Salazar, the shooting-gallery targets, object classes.
    const uint8_t fixed[] = {0x00, 0x03, 0x04, 0x0F, 0x33, 0x37, 0x3E, 0x3F, 0x40, 0x4C, 0xFF};
#ifndef RE4_RANDOM_INCLUDE_PROTECTED
    assert(re4_actor_pool_index(0x18) < 0 && re4_actor_pool_index(0x2F) < 0 && re4_actor_pool_index(0x30) < 0);   // merchant, Del Lago, Saddler
    assert(re4_random_entity_id(0x18, 1, 2, 3, 0) == 0x18 && re4_random_entity_id(0x2F, 1, 2, 3, 0) == 0x2F && re4_random_entity_id(0x30, 1, 2, 3, 0) == 0x30);
    for (uint32_t i = 0; i < 4000; ++i) {
        const uint8_t g = re4_random_entity_id(0x10, 9, 0x0102, i, 0);
        assert(g != 0x18 && g != 0x2F && g != 0x30);
    }
#endif
    assert(re4_actor_pool_index(0x31) >= 0 && re4_actor_pool_index(0x2A) >= 0);   // giant Salazar, traps
    // everything with a module of its own is in: fish, chicken, vehicles, gallery targets
    assert(re4_actor_pool_index(0x27) >= 0 && re4_actor_pool_index(0x28) >= 0 && re4_actor_pool_index(0x3A) >= 0 &&
           re4_actor_pool_index(0x3B) >= 0 && re4_actor_pool_index(0x3D) >= 0);
    assert(re4_actor_pool_index(0x3E) < 0);   // gallery targets crash outside the gallery
    for (uint32_t i = 0; i < sizeof(fixed); ++i) {
        for (uint32_t a = 0; a < 4; ++a) {
            assert(re4_random_entity_id(fixed[i], 123, 0x0102, 7, a) == fixed[i]);
        }
        assert(re4_actor_pool_index(fixed[i]) < 0);
    }

    // The pool has no duplicates and no id of the "never" list.
    for (uint32_t i = 0; i < RE4_ACTOR_ID_COUNT; ++i) {
        for (uint32_t j = i + 1; j < RE4_ACTOR_ID_COUNT; ++j) assert(RE4_ACTOR_IDS[i] != RE4_ACTOR_IDS[j]);
        assert(RE4_ACTOR_IDS[i] != 0x33 && RE4_ACTOR_IDS[i] != 0x37 && RE4_ACTOR_IDS[i] != 0x3E);
        assert(RE4_ACTOR_IDS[i] >= 0x10 && RE4_ACTOR_IDS[i] <= 0x3E);
    }

    // Every pool id maps into the pool, for several seeds and attempts.
    for (uint32_t i = 0; i < RE4_ACTOR_ID_COUNT; ++i) {
        for (uint32_t seed = 0; seed < 5; ++seed) {
            for (uint32_t a = 0; a < 8; ++a) {
                assert(re4_actor_pool_index(re4_random_entity_id(RE4_ACTOR_IDS[i], seed, 0x0102, i, a)) >= 0);
            }
        }
    }

    // Script-owned entries never change: the first Ganado of the house (r100 entry 0x25) and a whole room (r104).
    assert(re4_entity_protected(0x100, 0x25) && re4_entity_protected(0x104, 0x01) && !re4_entity_protected(0x100, 0xF0));
    for (uint32_t a = 0; a < 8; ++a) {
        assert(re4_random_entity_id(0x10, 5, 0x100, 0x25, a) == 0x10);
        assert(re4_random_entity_id(0x11, 5, 0x104, 0x01, a) == 0x11);
    }
    // Reproducible: same seed / room / entry / attempt -> same id.
    assert(re4_random_entity_id(0x10, 42, 0x7F1, 9, 0) == re4_random_entity_id(0x10, 42, 0x7F1, 9, 0));
    // The choice does not depend on the original id (only on seed, room, entry).
    assert(re4_random_entity_id(0x10, 42, 0x7F1, 9, 0) == re4_random_entity_id(0x2B, 42, 0x7F1, 9, 0));

    // Coverage: over many entries and one seed every pool id turns up, and none dominates.
    uint32_t hits[256] = {0};
    const uint32_t N = 20000;
    for (uint32_t e = 0; e < N; ++e) hits[re4_random_entity_id(0x10, 7, 0x7F1, e, 0)]++;
    for (uint32_t i = 0; i < RE4_ACTOR_ID_COUNT; ++i) {
        const uint32_t h = hits[RE4_ACTOR_IDS[i]];
        assert(h > N / RE4_ACTOR_ID_COUNT / 2);       // not starved
        assert(h < N / RE4_ACTOR_ID_COUNT * 2);       // not dominant
    }

    // Different seeds give different layouts; different attempts give different fallbacks.
    uint32_t seedDiff = 0, attemptDiff = 0;
    for (uint32_t e = 0; e < 200; ++e) {
        seedDiff += re4_random_entity_id(0x10, 1, 0x7F1, e, 0) != re4_random_entity_id(0x10, 2, 0x7F1, e, 0);
        attemptDiff += re4_random_entity_id(0x10, 1, 0x7F1, e, 0) != re4_random_entity_id(0x10, 1, 0x7F1, e, 1);
    }
    assert(seedDiff > 100 && attemptDiff > 100);

    // Ganado family helper: the merchant (0x18) is not a Ganado.
    assert(re4_is_ganado_id(0x10) && re4_is_ganado_id(0x20) && !re4_is_ganado_id(0x18) && !re4_is_ganado_id(0x21));

    // Hash: reproducible, depends on every input.
    assert(re4_entity_hash(1, 2, 3, 4) == re4_entity_hash(1, 2, 3, 4));
    assert(re4_entity_hash(1, 2, 3, 4) != re4_entity_hash(2, 2, 3, 4));
    assert(re4_entity_hash(1, 2, 3, 4) != re4_entity_hash(1, 3, 3, 4));
    assert(re4_entity_hash(1, 2, 3, 4) != re4_entity_hash(1, 2, 4, 4));
    assert(re4_entity_hash(1, 2, 3, 4) != re4_entity_hash(1, 2, 3, 5));
    // A new draw at every room load: the same entry gets different results over 64 loads.
    uint32_t seen[64] = {0}, distinct = 0;
    for (uint32_t load = 1; load <= 64; ++load) {
        const uint32_t v = re4_entity_hash(7, 0x0106, load * 256 + 3, 0) % RE4_ACTOR_ID_COUNT;
        if (!seen[v]) { seen[v] = 1; ++distinct; }
    }
    assert(distinct > 15);

    // Script-held entries: the first Ganado's room list entries (r100) and whole rooms with variable access.
    assert(re4_entity_protected(0x100, 0x03) && re4_entity_protected(0x100, 0x0C));
    assert(re4_entity_protected(0x104, 0x01) && re4_entity_protected(0x404, 0x7F));   // whole rooms
    assert(!re4_entity_protected(0xFFFF, 0));
    // Event enemies: rooms whose script keeps the returned object are held (r100); the village raid room is not.
    assert(re4_entity_event_held(0x100) && !re4_entity_event_held(0x106));
    assert(RE4_RANDOM_KEEP_STAGE == 1 && RE4_RANDOM_KEEP_LAST_ROOM == 0);   // only the first room stays vanilla

    // Tiers: the pool has ultra, hard and comic actors, and the comic ones are a minority.
    uint32_t nt[3] = {0, 0, 0};
    for (uint32_t i = 0; i < RE4_ACTOR_ID_COUNT; ++i) nt[re4_entity_tier(RE4_ACTOR_IDS[i])]++;
    assert(nt[2] >= 8 && nt[1] >= 15 && nt[0] >= 6);
    assert(re4_entity_tier(0x39) == 2 && re4_entity_tier(0x2D) == 2 && re4_entity_tier(0x10) == 1 && re4_entity_tier(0x28) == 0);
    // pins: the script of r101 reads module 0x15 directly
    assert(re4_pin_module(0x101, 0x15) && !re4_pin_module(0x101, 0x16) && re4_pin_room(0x104));   // a room whose script reaches entries through a variable

    printf("pool size %u\n", (unsigned) RE4_ACTOR_ID_COUNT);
    return 0;
}
