#ifndef RE4_ENTITY_RANDOM_H
#define RE4_ENTITY_RANDOM_H

// Entity randomizer: deterministic pool + selector (host-testable, no game headers).
//
// The pool was checked against the game's own tables (tools/check_entity_pool.py):
//   - src/game/read.cpp EmFileTbl[id]  -> every pool id has a module of its OWN (em<id>.drs).
//   - config/G4BE08/modules/em<id>     -> that module exists.
//   - ids 0x33 and 0x37 have NO module of their own (EmFileTbl points them at the Ganado
//     placeholder 0x18/0x19; em34 builds them from cModel::type), so EmCreate(0x33/0x37) would
//     load em10 and hand out a Ganado carrying a wrong id. They are never used.
//
// What is in the pool (and so can replace, and be replaced by, each other): EVERY actor that has a module of
// its own - Ganados, animals, traps, sub-bosses, bosses, vehicles - except the protected
// ones: the merchant (0x18, so the shop is always there), Del Lago (0x2F) and Saddler (0x30).
// RE4_RANDOM_INCLUDE_PROTECTED puts those three in as well.
// Entries a room script holds (entity_random_protect.h, generated from src/st*/r*.cpp by
// tools/gen_entity_protect.py) are never replaced: the script treats them as one class or waits for them.
// Only the room's own list is randomized (EmSetFromList, when a room or checkpoint loads); what scripts and
// events create later is not.
//
// NOTE: a successful EmCreate() proves only that the module could be loaded; it does not prove
// that the room's script, route, animations or the boss phases suit the new actor.

#include <stdint.h>

// First zone kept exactly as the game made it (no enemy of those rooms is touched): stage 1 (the village
// chapter), rooms r100 .. r10<LAST_ROOM> (hex): by default only r100, the first room. Change these two numbers to move the limit.
#ifndef RE4_RANDOM_KEEP_STAGE
#define RE4_RANDOM_KEEP_STAGE 1
#endif
#ifndef RE4_RANDOM_KEEP_LAST_ROOM
#define RE4_RANDOM_KEEP_LAST_ROOM 0
#endif
// The room that loads right before r100 (the opening) stays as the game made it too.
#ifndef RE4_RANDOM_KEEP_EXTRA_ROOM
#define RE4_RANDOM_KEEP_EXTRA_ROOM 0x0120
#endif
#include "entity_random_protect.h"

// By default scripts' enemies ARE randomized too (EmSetFromList2, EmSetEvent, list entries a script takes by
// number): only the first zone stays vanilla. -DRE4_RANDOM_RESPECT_SCRIPTS brings back the protection of the
// entries / rooms listed in entity_random_protect.h.
// Rooms that must never be randomized (room key = stage << 8 | room): add the room the log names after a crash.
static const uint16_t RE4_NEVER_ROOMS[] = {
    0xFFFF   // end marker
};
static inline int re4_room_never(uint32_t room_key)
{
    uint32_t i;
    for (i = 0; RE4_NEVER_ROOMS[i] != 0xFFFF; ++i) {
        if (RE4_NEVER_ROOMS[i] == room_key) return 1;
    }
    return 0;
}

static const uint8_t RE4_ACTOR_IDS[] = {
    // Ganado variants (em10..em17, em19..em20); em18 is the merchant
    0x10, 0x11, 0x12, 0x13, 0x14, 0x15, 0x16, 0x17,
#ifdef RE4_RANDOM_INCLUDE_PROTECTED
    0x18,                   // merchant
#endif
    0x19, 0x1A, 0x1B, 0x1C, 0x1D, 0x1E, 0x1F, 0x20,
    // animals, creatures, traps
    0x21, 0x22,             // village dog, dog
    0x23, 0x24, 0x25,       // crow, snake (box ambusher), parasite
    0x26, 0x27, 0x28, 0x29, // large stationary biter, fish, chicken, bats
    0x2A,                   // traps
    // sub-bosses and bosses on their own module
    0x2B, 0x2C, 0x2D, 0x2E, // El Gigante, insect boss, Novistador, crawler
#ifdef RE4_RANDOM_INCLUDE_PROTECTED
    0x2F, 0x30,             // Del Lago, Saddler
#endif
    0x31, 0x32,             // giant Salazar, U-3
    0x34, 0x35, 0x36,       // Mendez forms, Regenerator
    0x38, 0x39,             // multi-enemy boss, Krauser (knife fight)
    0x3A, 0x3B, 0x3C, 0x3D  // gunship, truck, armoured humanoid, support helicopter
};
// 0x3E (the gallery targets, cEmMark) is NOT in the pool: it dereferences data that only the shooting
// gallery sets up, and crashed (signal 11 in cEmMark::move) when it was created in an ordinary room.
#define RE4_ACTOR_ID_COUNT ((uint32_t)(sizeof(RE4_ACTOR_IDS) / sizeof(RE4_ACTOR_IDS[0])))

// Ids of the Ganado family: they share one class (em10.cpp), so the list entry's `type`
// (weapon / look) is meaningful between them.
static inline int re4_is_ganado_id(uint8_t id)
{
    return id >= 0x10 && id <= 0x20 && id != 0x18;
}

static inline uint32_t re4_entity_mix(uint32_t x)
{
    x ^= x >> 16;
    x *= 0x7FEB352Du;
    x ^= x >> 15;
    x *= 0x846CA68Bu;
    x ^= x >> 16;
    return x;
}

// How hard an actor is to meet: 2 = ultra (bosses, sub-bosses, brutes), 1 = hard (the Ganado family and the other
// ordinary enemies), 0 = comic (animals, traps, vehicles: rare, for the laugh).
static inline int re4_entity_tier(uint8_t id)
{
    switch (id) {
    case 0x2B: case 0x2C: case 0x2D: case 0x30: case 0x31: case 0x32: case 0x2F:
    case 0x34: case 0x35: case 0x36: case 0x38: case 0x39: case 0x3C:
        return 2;
    case 0x23: case 0x24: case 0x27: case 0x28: case 0x29: case 0x2A: case 0x3A: case 0x3B: case 0x3D:
        return 0;
    default:
        return 1;
    }
}

static inline int re4_actor_pool_index(uint8_t id)
{
    uint32_t i;
    for (i = 0; i < RE4_ACTOR_ID_COUNT; ++i) {
        if (RE4_ACTOR_IDS[i] == id) return (int)i;
    }
    return -1;
}

// Seeded, reproducible 32-bit hash of three values (room load, entry, attempt ...).
static inline uint32_t re4_entity_hash(uint32_t seed, uint32_t a, uint32_t b, uint32_t c)
{
    return re4_entity_mix(seed * 0x9E3779B1u ^ re4_entity_mix(a ^ re4_entity_mix(b * 0x85EBCA6Bu + c * 0xC2B2AE35u)));
}

// Replacement for list entry (room_key, entry_key). `attempt` 0 is the first choice; higher
// attempts give further, equally reproducible choices (used when the first one cannot be loaded).
// An id outside the pool is returned unchanged.
static inline uint8_t re4_random_entity_id(uint8_t original, uint32_t seed,
                                           uint32_t room_key, uint32_t entry_key,
                                           uint32_t attempt)
{
    uint32_t h;
    if (re4_actor_pool_index(original) < 0) return original;
    if (re4_entity_protected(room_key, entry_key)) return original;
    h = re4_entity_mix(seed * 0x9E3779B1u ^
                       re4_entity_mix(room_key ^ (entry_key * 0x85EBCA6Bu)));
    h = re4_entity_mix(h + attempt * 0x9E3779B9u);
    return RE4_ACTOR_IDS[h % RE4_ACTOR_ID_COUNT];
}

#endif
