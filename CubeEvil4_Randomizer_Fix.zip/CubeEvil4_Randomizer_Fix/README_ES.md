# Randomizer de entidades para CubeEvil4-Android 0.99.10-rc — paquete corregido

## Cómo aplicarlo
1. Parte de tus archivos **originales de 0.99.10-rc** (o del árbol donde copiaste el primer ZIP: el script reconoce
   ese estado y lo actualiza). **Importante:** `cheats.cpp`, `CoreMenu.java` y los `strings_ingame.xml` (en, es)
   que venían en el primer ZIP son de la 0.99.8 y pisaron los de 0.99.10; restáuralos desde tu copia original
   (git o el ZIP del juego) antes de aplicar, o se perderán funciones de 0.99.9/0.99.10.
2. Descomprime este paquete y ejecuta:
   `python3 apply_randomizer_fix.py /ruta/a/CubeEvil4-Android-0.99.10-rc`
   (`--check` solo muestra qué cambiaría). Es idempotente y guarda respaldos en `.randomizer_backup/`.
   Si un ancla no se encuentra, **no escribe nada** y te dice cuál; ver "Edición manual".
3. Comprueba: `python3 tools/check_entity_pool.py .` y `sh port/whole/runtime/tests/run_entity_random_test.sh`.
4. Compila como siempre (`port/tools/whole_build.sh`, Gradle).

## Qué se corrigió
| Problema | Efecto | Corrección |
|---|---|---|
| Archivos de 0.99.8 sobre 0.99.10 | Faltan ~45/74 cadenas (`ingame_bench_*`, `ingame_profile_*`...), falta `re4_story_char_card_items` (error de enlazado, parche 0228) | Restaurar originales y aplicar solo los cambios mínimos con el script |
| Bit 31 dentro de `gWanted` (centinela `< 0`) | Con "Random entities" activo nunca actuaba y se apagaban los otros trucos | El bit 31 va a un atómico aparte (`gEntityOn`); `gWanted` sigue siendo ≥ 0 |
| IDs 0x33 y 0x37 en el catálogo | No tienen módulo propio: se crearía un Ganado con ID erróneo | Excluidos |
| `readEm` deja `Disp_flg = 0xFFFFFFFF` sin ranura libre | Banderas de depuración activadas | Se comprueba la ranura antes y se restaura `Disp_flg` |
| Consumir las 4 ranuras de módulos | Los eventos de la sala podían fallar al cargar | Se deja 1 ranura libre (`RE4_RANDOM_KEEP_FREE_SLOTS`) |
| Un solo intento de reemplazo | Casi siempre caía al enemigo original | Hasta 8 candidatos reproducibles (`RE4_RANDOM_TRIES`) |
| `type` del enemigo original aplicado a otra clase | Variantes inválidas | `type = 0` salvo Ganado→Ganado |
| Semilla compartida con Objetos aleatorios | Apagar uno borraba la semilla del otro | Se conserva mientras uno de los dos esté activo |
| Cadenas solo en en/es | Falta traducción | 11 idiomas |

## Cómo funciona ahora (versión 3)
- **Cuándo cambia:** solo al **cargar una sala** (partida nueva, cargar partida, reiniciar sala o punto de control).
  Cada carga hace un sorteo nuevo (misma semilla, otra tirada), así que recargar la zona cambia los enemigos.
  Activar el interruptor a mitad de una sala no cambia nada hasta la siguiente carga.
- **Qué se reemplaza:** (1) los enemigos de la lista de la sala al cargarla (`EmSetFromList`) y (2) los que crean
  los eventos con `EmSetEvent` (p. ej. las oleadas de la emboscada del pueblo), salvo en las 6 salas cuyo guion guarda
  el objeto que devuelve (r100, r208, r222, r22c, r402, r405). **No se reemplazan** los que los guiones piden por
  número de lista (`EmSetFromList2`): el guion guarda el objeto y lo trata como una clase concreta.
- **Paleta por sala (variedad de otros capítulos):** el juego solo tiene 4 "ranuras" de módulos de enemigos y cada
  sala las llena con los suyos, así que nada de otro capítulo podía entrar (en tu registro: "0 module slots free").
  Ahora hay **8 ranuras** (`RE4_EM_SLOTS`, el script lo cambia en `read.h`, `read.cpp` y `exception.cpp`). Al cargar la
  sala se arma una paleta con los módulos de la propia sala + hasta 3 módulos nuevos sorteados de TODO el catálogo
  (castillo, isla...), cargados en ese momento como los de la sala, nunca durante el juego. 3 de cada 4 sorteos salen
  de los módulos nuevos. Siempre queda 1 ranura libre (`RE4_RANDOM_MAX_NEW`, `RE4_RANDOM_KEEP_FREE_SLOTS`). Si un
  sorteo no se puede servir, sale el enemigo original.
- **Primera zona intacta** (solo la zona anterior al pueblo, NO todo el capítulo 1): salas r100–r105 del capítulo 1 y la sala r120 (la que carga justo antes de r100) (`RE4_RANDOM_KEEP_STAGE`,
  `RE4_RANDOM_KEEP_LAST_ROOM` en `entity_random.h`). Para moverla, cambia esos dos números.
- **Entradas protegidas:** los guiones toman enemigos por su número de lista y los tratan como una clase
  (`(cEmGanado*)`...) o esperan su muerte. `tools/gen_entity_protect.py` las extrae del código y genera
  `entity_random_protect.h` (419 entradas + 31 salas enteras donde el guion usa índices variables). El script de
  aplicación lo regenera sobre tu código.
- **Catálogo (42 IDs), todo actor con módulo propio, sin excepción:** Ganados (0x10–0x17, 0x19–0x20), perros,
  cuervo, serpiente, parásito, 0x26, pez, gallina, murciélagos, trampas, El Gigante, jefes de insecto, Novistador,
  0x2E, Salazar gigante 0x31, U-3, Mendez, Regenerador, 0x38, Krauser, helicóptero de combate, camión, 0x3C,
  helicóptero de apoyo y blancos de tiro.
  **Protegidos** (ni se reemplazan ni aparecen): mercader (0x18), Del Lago (0x2F), Saddler (0x30)
  (`-DRE4_RANDOM_INCLUDE_PROTECTED` los incluye). **Fuera:** 0x33/0x37/0x3F (sin módulo) y objetos 0x40+.
  `tools/check_entity_pool.py` lo verifica contra las tablas del juego.
- **Registro:** `logs/core-log.txt` (carpeta de la app) anota cada sala ("random: room 0x0106 load 3 ...") y cada
  cambio ("entry 12: 0x10 -> 0x2B") y cada módulo que carga. Tras un cierre, la última línea "random:" indica qué ID
  estaba en juego: se quita del catálogo en `entity_random.h`.
- **Riesgos conocidos:** una trampa, un vehículo o un blanco en lugar de un enemigo pueden dejar una sala sin
  abrirse (si un evento espera su muerte); sale por el registro y se quita ese ID.

## Límites conocidos (sin probar en dispositivo)
- Solo hay 4 ranuras de módulos de enemigo: la variedad real depende de las que estén libres en cada sala.
- El HP viene de la entrada original de la sala (un Ganado con HP de jefe, o al revés).
- Un reemplazo puede no encajar con los guiones de su sala (jefes con fases, vehículos); conserva una partida de reserva.
- `src/game/em_set.cpp` queda modificado: afecta solo al SHA1 de la compilación GameCube, no al port Android.

## Edición manual (si el script se detiene)
- `cheats.cpp`: quitar `kEntityRandom` del enum y de `kAll`; tras `std::atomic<int> gWanted(-1);` añadir
  `const unsigned kEntityBit = 0x80000000u; std::atomic<int> gEntityOn(0);`; `re4_cheats_set` debe poner
  `gEntityOn` desde `bits & kEntityBit` y guardar `bits & kAll` en `gWanted`; definir
  `extern "C" u8 re4_random_enemy_id(u8, u32, u32, u32 attempt)` (ver el script, constantes `NEW_SET` y `NEW_SELECTOR`).
- `CoreMenu.java`: constantes, `withRandomItems/withRandomEntities` y el interruptor (`NEW_CONSTS`, `NEW_FUNCS`, `NEW_UI`).
- `strings_ingame.xml`: claves `ingame_cheat_random_entities` y `_help` (diccionario `STRINGS`).

## Qué se verificó
Pruebas unitarias del selector, verificador de catálogo contra `EmFileTbl`/módulos, `whole_prepare.py` con los 228
parches, comprobación de sintaxis con g++ de `em_set.cpp` y `cheats.cpp` preparados, XML válido, script idempotente.
**No se compiló** con clang/Gradle ni se probó en juego (no disponibles aquí): confirma con tu build.

## Compilar en GitHub (sin instalar nada en el PC)
Copia `.github/workflows/build-core.yml` y la carpeta `CubeEvil4_Randomizer_Fix/` (este paquete) a tu repositorio
en GitHub; en la pestaña **Actions → Build core APK → Run workflow** compila el núcleo y la APK `core` y la deja como
*artifact* descargable. Si falla, el artifact `build-logs` trae los registros.
