# Randomizer de entidades para CubeEvil4-Android 0.99.10-rc — paquete corregido

## Cómo aplicarlo
1. Parte de tus archivos **originales de 0.99.10-rc** (o del árbol donde copiaste el primer ZIP: el script reconoce
   ese estado y lo actualiza). **Importante:** `cheats.cpp`, `CoreMenu.java` y los `strings_ingame.xml` (en, es)
   que venían en el primer ZIP son de la 0.99.8 y pisaron los de 0.99.10; restáuralos desde tu copia original
   (git o el ZIP del juego) antes de aplicar, o se perderán funciones de 0.99.9/0.99.10.
2. Descomprime este paquete y ejecuta:
   `python3 apply_randomizer_fix.py /ruta/a/CubeEvil4-Android-0.99.10-rc`
   (`--check` solo muestra qué cambiaría). Es idempotente y guarda respaldos en `.randomizer_backup/`.
   Si un ancla no se encuentra, **no escribe nada** y te dice cuál; ver "Edición manual".
3. Comprueba: `python3 tools/check_entity_pool.py .` y `sh port/whole/runtime/tests/run_entity_random_test.sh`.
4. Compila como siempre (`port/tools/whole_build.sh`, Gradle).

## Qué se corrigió
| Problema | Efecto | Corrección |
|---|---|---|
| Archivos de 0.99.8 sobre 0.99.10 | Faltan ~45/74 cadenas (`ingame_bench_*`, `ingame_profile_*`...), falta `re4_story_char_card_items` (error de enlazado, parche 0228) | Restaurar originales y aplicar solo los cambios mínimos con el script |
| Bit 31 dentro de `gWanted` (centinela `< 0`) | Con "Random entities" activo nunca actuaba y se apagaban los otros trucos | El bit 31 va a un atómico aparte (`gEntityOn`); `gWanted` sigue siendo ≥ 0 |
| IDs 0x33 y 0x37 en el catálogo | No tienen módulo propio: se crearía un Ganado con ID erróneo | Excluidos |
| `readEm` deja `Disp_flg = 0xFFFFFFFF` sin ranura libre | Banderas de depuración activadas | Se comprueba la ranura antes y se restaura `Disp_flg` |
| Consumir las 4 ranuras de módulos | Los eventos de la sala podían fallar al cargar | Se deja 1 ranura libre (`RE4_RANDOM_KEEP_FREE_SLOTS`) |
| Un solo intento de reemplazo | Casi siempre caía al enemigo original | Hasta 8 candidatos reproducibles (`RE4_RANDOM_TRIES`) |
| `type` del enemigo original aplicado a otra clase | Variantes inválidas | `type = 0` salvo Ganado→Ganado |
| Semilla compartida con Objetos aleatorios | Apagar uno borraba la semilla del otro | Se conserva mientras uno de los dos esté activo |
| Cadenas solo en en/es | Falta traducción | 11 idiomas |

## Cómo funciona ahora (versión 3)
- **Cuándo cambia:** solo al **cargar una sala** (partida nueva, cargar partida, reiniciar sala o punto de control).
  Cada carga hace un sorteo nuevo (misma semilla, otra tirada), así que recargar la zona cambia los enemigos.
  Activar el interruptor a mitad de una sala no cambia nada hasta la siguiente carga.
- **Qué se reemplaza:** todo: los enemigos de la lista de la sala al cargarla (`EmSetFromList`), los que los guiones
  piden por número de lista (`EmSetFromList2`) y los de eventos (`EmSetEvent`, p. ej. la emboscada del pueblo). Solo la
  primera zona queda vanilla. Algún guion podría no aceptar un reemplazo: el registro nombra la sala
  ("random: room 0x....") y se apaga añadiéndola a `RE4_NEVER_ROOMS` en `entity_random.h`.
  Compilando con `-DRE4_RANDOM_RESPECT_SCRIPTS` vuelve la protección de 419 entradas / 31 salas / 6 salas de eventos
  (`entity_random_protect.h`).
- **Más memoria para los enemigos (la causa de la poca variedad):** el registro decía `heap: no room for 0x2a6240
  bytes in heap 4 ... free[1487a0]`. Los módulos de enemigos cargan en el montón nº 4, que tras cargar los Ganados
  de la sala (4 MB cada uno) solo tenía 1.3 MB libres, y ningún jefe (2.8 MB o más) cabía. El port reserva 48 MB como
  una consola de desarrollo, pero el juego solo usa el mapa de 24 MB (+1 MB). El script amplía el final de los
  montones **20 MB más** (`RE4_MEM1_LP64_HEAP_EXTRA` en `re4_runtime.h` y `lp64_sizes.json`, que deben coincidir); el
  montón 4, el último de la cadena, recibe todo ese espacio. Solo aplica a 64 bits (arm64-v8a).
- **Presupuestos de recursos por sala (causa del cierre `cEm3c::move` -> `EmAtCheck` -> `C_VECAdd`, signal 11):**
  cada sala declara en sus datos cuántos enemigos, modelos, partes, efectos... necesita (`ConsGetRoomValue(CONS_R_NEM,
  NPARTS, NMODELINFO, ...)`), dimensionados para SUS enemigos. Cambiar trece gallinas por enemigos con varios
  modelos y decenas de partes agotaba el presupuesto: `partsWorldCalc() MODEL HAS NO PARTS` y luego el cierre. Con el
  randomizer activo, `cons.cpp` (parche del script) multiplica por 4 (+16) los presupuestos relacionados con
  enemigos (NEM, NESP, NESPGEN, NCTRL, NLIGHT, NPARTS, NMODELINFO, NSAT, NEAT); el propio juego ya duplica tres de
  ellos con `DBG_APP_USE_DBMEM`. Ajuste: `RE4_RANDOM_POOL_SCALE`.
- **Sonido (causa del cierre `SEQ data error ... OSPanic snd_seq2.cpp`):** el sonido de la sala, de los pasos y de
  cada módulo de enemigo se apila en dos zonas fijas: 64 KB de RAM de sonido y la ARAM de 0x1F4100 a 0x700000
  (5.3 MB), justo debajo de los datos de la música. Un Ganado solo ya trae 2 MB de muestras, y el módulo que traía el
  randomizer se salía de la zona y **pisaba la música**. `dvd.cpp` (parche del script) ahora omite el banco de sonido
  de un enemigo que no cabe, igual que el juego omite uno ya cargado: ese enemigo funciona sin sonido propio
  (`emSeCheck` no encuentra banco y no suena nada). El registro lo anota: "DVD: Snd block does not fit".
- **Paleta por niveles (variedad y reto):** al cargar una sala (`EmSetFromList`) se arma una paleta con los módulos de
  enemigos ya cargados y se cargan, de CUALQUIER capítulo, módulos nuevos del más grande al más pequeño. Niveles
  (según lo que es cada módulo en `src/em*/`):
  - **Jefe / subjefe:** El Gigante, el jefe de insecto, el Salazar gigante, el jefe enjaulado (U-3), Mendez, el jefe de
    la sala de rayos, el jefe formado por varios enemigos y Krauser (duelo de cuchillos).
  - **Élite:** el Novistador (insecto camuflado), el regenerador, el humanoide que revienta su cabeza y el grande
    estacionario que muerde. Peligrosos, pero enemigos normales, no jefes.
  - **Común:** los 16 módulos de Ganado (motosierras incluidas, según el módulo), perros, parásito, el pequeño que se
    arrastra y el que salta de la caja.
  - **Cómico:** cuervo, pez, gallina, murciélagos, trampas, helicópteros y camión.
  Por sala se cargan, por orden de prioridad: un jefe, uno élite, un común que NO es Ganado (perros, parásito...),
  una variante de Ganado (70 %), un segundo élite (50 %), un segundo común y, en 1 de cada 3, uno cómico
  (`RE4_RANDOM_MAX_NEW` 7, 10 ranuras de módulos). Cada enemigo sortea: 12 % jefe (máx. 2 por carga), 38 % élite,
  7 % cómico, el resto común. **Un enemigo nunca vuelve a sortear su propio tipo y un Ganado nunca se cambia por otro
  Ganado** (solo si no hay otra cosa cargada, tras 6 intentos): si no hay otro cargado o no cabe, queda como estaba.
- **Tipos válidos en vez de borrarlos (armas, motosierras...):** cada módulo de Ganado trae en `emXX_set.cpp` la lista
  de tipos de modelo que puede construir (por ejemplo `em15`: 0, 3, 4, 11; `em1d`: 2 y 14-21; la motosierra del pueblo es el
  tipo 4 y la de la isla el 22). `tools/gen_ganado_types.py` la extrae del código. Un Ganado del módulo B recibe el tipo
  que tenía el original si B lo tiene; si no, uno de B, con un 40 % de preferencia por los especiales (motosierra,
  encapuchado con parásito, artillero). `Character` (la personalidad: ataca, espera...) significa lo mismo en todos
  los Ganados y se conserva. Otros enemigos usan la variante 0.
- **El juego aprende de cada cierre (sin quitar nada a mano):** antes de construir un enemigo sustituido se escribe
  `entity_random_marker.txt` junto al registro (`logs/`) y se borra tras su primer movimiento. Si la siguiente
  ejecución lo encuentra, el cierre ocurrió construyendo ese enemigo: esa combinación módulo/tipo queda en
  `entity_random_ban.txt` y no vuelve a sortearse (un segundo tipo del mismo módulo, o cualquier otro actor, bloquea
  el módulo entero). Borra `entity_random_ban.txt` para perdonar todo.
- **Sonido (causa del cierre `SEQ data error`) sin dejar mudos a los enemigos:** el sonido de sala, pasos, enemigos y
  música comparte unos 5 MB de ARAM. `entity_random.h` trae el tamaño medido de 33 módulos y `em_set.cpp` elige primero
  los módulos cuyo sonido **cabe en lo que queda** o ya está cargado (las variantes de Ganado comparten banco:
  0x10/0x12/0x13, 0x11/0x14/0x19-0x1C, 0x1D-0x20). Solo si no hay otro, carga uno mudo. `dvd.cpp` sigue omitiendo el
  banco que no cabe (esa es la protección que evita pisar la música).
- **Presupuestos de recursos por sala (causa del cierre `cEm3c::move` -> `EmAtCheck` -> `C_VECAdd`, signal 11):**
  cada sala declara en sus datos cuántos enemigos, modelos, partes, efectos... necesita (`ConsGetRoomValue(CONS_R_NEM,
  NPARTS, NMODELINFO, ...)`), dimensionados para SUS enemigos. Cambiar trece gallinas por enemigos con varios
  modelos y decenas de partes agotaba el presupuesto: `partsWorldCalc() MODEL HAS NO PARTS` y luego el cierre. Con el
  randomizer activo, `cons.cpp` (parche del script) multiplica por 4 (+16) los presupuestos relacionados con
  enemigos (NEM, NESP, NESPGEN, NCTRL, NLIGHT, NPARTS, NMODELINFO, NSAT, NEAT); el propio juego ya duplica tres de
  ellos con `DBG_APP_USE_DBMEM`. Ajuste: `RE4_RANDOM_POOL_SCALE`.
- **Sonido (causa del cierre `SEQ data error ... OSPanic snd_seq2.cpp`):** el sonido de la sala, de los pasos y de
  cada módulo de enemigo se apila en dos zonas fijas: 64 KB de RAM de sonido y la ARAM de 0x1F4100 a 0x700000
  (5.3 MB), justo debajo de los datos de la música. Un Ganado solo ya trae 2 MB de muestras, y el módulo que traía el
  randomizer se salía de la zona y **pisaba la música**. `dvd.cpp` (parche del script) ahora omite el banco de sonido
  de un enemigo que no cabe, igual que el juego omite uno ya cargado: ese enemigo funciona sin sonido propio
  (`emSeCheck` no encuentra banco y no suena nada). El registro lo anota: "DVD: Snd block does not fit".
- **Paleta por niveles (variedad y reto):** al cargar una sala (`EmSetFromList`) se arma una paleta con los módulos de
  enemigos ya cargados y se cargan, de CUALQUIER capítulo, módulos nuevos del más grande al más pequeño. Niveles
  (según lo que es cada módulo en `src/em*/`):
  - **Jefe / subjefe:** El Gigante, el jefe de insecto, el Salazar gigante, el jefe enjaulado (U-3), Mendez, el jefe de
    la sala de rayos, el jefe formado por varios enemigos y Krauser (duelo de cuchillos).
  - **Élite:** el Novistador (insecto camuflado), el regenerador, el humanoide que revienta su cabeza y el grande
    estacionario que muerde. Peligrosos, pero enemigos normales, no jefes.
  - **Común:** los 16 módulos de Ganado (motosierras incluidas, según el módulo), perros, parásito, el pequeño que se
    arrastra y el que salta de la caja.
  - **Cómico:** cuervo, pez, gallina, murciélagos, trampas, helicópteros y camión.
  Por sala se cargan, por orden de prioridad: un jefe, uno élite, un común que NO es Ganado (perros, parásito...),
  una variante de Ganado (70 %), un segundo élite (50 %), un segundo común y, en 1 de cada 3, uno cómico
  (`RE4_RANDOM_MAX_NEW` 7, 10 ranuras de módulos). Cada enemigo sortea: 12 % jefe (máx. 2 por carga), 38 % élite,
  7 % cómico, el resto común. **Un enemigo nunca vuelve a sortear su propio tipo y un Ganado nunca se cambia por otro
  Ganado** (solo si no hay otra cosa cargada, tras 6 intentos): si no hay otro cargado o no cabe, queda como estaba.
- **Variante de modelo reiniciada en toda sustitución:** `type` y `Character` (variante de modelo, arma y movimientos)
  solo valen para las tablas de UN módulo. Conservarlos en Ganado → Ganado causó el cierre
  `HermiteInterpolation` / `MotionSetCore` en `cEm10::move` (módulo `em16`, línea `entry 22: 0x15 -> 0x16`). Ahora
  siempre se usa la variante 0, que existe en todos los módulos.
- **Módulos anclados:** nunca se libera un módulo que un guion lee directamente (`SearchEmModule(id)` literal), el de
  una entrada cuya escena se carga con su id (`GetEmIdFromList`), ni ninguno en las 31 salas donde el guion usa
  índices variables. La tabla sale de `tools/gen_entity_protect.py`.
- **Solo la primera sala queda vanilla:** r100 (capítulo 1, `RE4_RANDOM_KEEP_STAGE`/`RE4_RANDOM_KEEP_LAST_ROOM` en
  `entity_random.h`) y r120, la escena de apertura que carga justo antes y no tiene enemigos propios. Todo lo demás se
  aleatoriza. Cada línea del registro dice la sala y el cambio.
- **Cada recarga es como una semilla nueva:** cada vez que una sala carga (reiniciar sala, cargar punto de control,
  morir y reintentar, salir y volver a entrar) se hace un sorteo completamente nuevo: otros módulos nuevos, otra
  paleta y otro reparto de enemigos. La paleta solo vale para la sala para la que se hizo.
- **Dificultad:** sale de la variedad (Ganados, perros, jefes, trampas, de cualquier capítulo). La vida (HP) la sigue
  dando la entrada original de la sala, así que un jefe en el puesto de un Ganado puede caer rápido y un Ganado en el
  de un jefe puede ser muy resistente. No hay tabla de vida por clase para corregirlo sin inventar números.
- **Catálogo (41 IDs), todo actor con módulo propio, sin excepción:** Ganados (0x10–0x17, 0x19–0x20), perros,
  cuervo, serpiente, parásito, 0x26, pez, gallina, murciélagos, trampas, El Gigante, jefes de insecto, Novistador,
  0x2E, Salazar gigante 0x31, U-3, Mendez, Regenerador, 0x38, Krauser, helicóptero de combate, camión, 0x3C,
  helicóptero de apoyo. **Fuera: 0x3E, los blancos de tiro** (cierre por `cEmMark::move`, signal 11: necesita datos que solo prepara la galería de tiro).
  **Protegidos** (ni se reemplazan ni aparecen): mercader (0x18), Del Lago (0x2F), Saddler (0x30)
  (`-DRE4_RANDOM_INCLUDE_PROTECTED` los incluye). **Fuera:** 0x33/0x37/0x3F (sin módulo) y objetos 0x40+.
  `tools/check_entity_pool.py` lo verifica contra las tablas del juego.
- **Registro:** `logs/core-log.txt` (carpeta de la app) anota cada sala ("random: room 0x0106 load 3 ...") y cada
  cambio ("entry 12: 0x10 -> 0x2B") y cada módulo que carga. Tras un cierre, la última línea "random:" indica qué ID
  estaba en juego: se quita del catálogo en `entity_random.h`.
- **Riesgos conocidos:** una trampa, un vehículo o un blanco en lugar de un enemigo pueden dejar una sala sin
  abrirse (si un evento espera su muerte); sale por el registro y se quita ese ID.

## Límites conocidos (sin probar en dispositivo)
- Solo hay 4 ranuras de módulos de enemigo: la variedad real depende de las que estén libres en cada sala.
- El HP viene de la entrada original de la sala (un Ganado con HP de jefe, o al revés).
- Un reemplazo puede no encajar con los guiones de su sala (jefes con fases, vehículos); conserva una partida de reserva.
- `src/game/em_set.cpp` queda modificado: afecta solo al SHA1 de la compilación GameCube, no al port Android.

## Edición manual (si el script se detiene)
- `cheats.cpp`: quitar `kEntityRandom` del enum y de `kAll`; tras `std::atomic<int> gWanted(-1);` añadir
  `const unsigned kEntityBit = 0x80000000u; std::atomic<int> gEntityOn(0);`; `re4_cheats_set` debe poner
  `gEntityOn` desde `bits & kEntityBit` y guardar `bits & kAll` en `gWanted`; definir
  `extern "C" u8 re4_random_enemy_id(u8, u32, u32, u32 attempt)` (ver el script, constantes `NEW_SET` y `NEW_SELECTOR`).
- `CoreMenu.java`: constantes, `withRandomItems/withRandomEntities` y el interruptor (`NEW_CONSTS`, `NEW_FUNCS`, `NEW_UI`).
- `strings_ingame.xml`: claves `ingame_cheat_random_entities` y `_help` (diccionario `STRINGS`).

## Qué se verificó
Pruebas unitarias del selector, verificador de catálogo contra `EmFileTbl`/módulos, `whole_prepare.py` con los 228
parches, comprobación de sintaxis con g++ de `em_set.cpp` y `cheats.cpp` preparados, XML válido, script idempotente.
**No se compiló** con clang/Gradle ni se probó en juego (no disponibles aquí): confirma con tu build.

## Compilar en GitHub (sin instalar nada en el PC)
Copia `.github/workflows/build-core.yml` y la carpeta `CubeEvil4_Randomizer_Fix/` (este paquete) a tu repositorio
en GitHub; en la pestaña **Actions → Build core APK → Run workflow** compila el núcleo y la APK `core` y la deja como
*artifact* descargable. Si falla, el artifact `build-logs` trae los registros.
