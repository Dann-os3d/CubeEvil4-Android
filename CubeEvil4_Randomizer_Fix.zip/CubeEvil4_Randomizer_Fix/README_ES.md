# Randomizer de entidades para CubeEvil4-Android 0.99.10-rc — paquete corregido

## Cómo aplicarlo
1. Parte de tus archivos **originales de 0.99.10-rc** (o del árbol donde copiaste el primer ZIP: el script reconoce
   ese estado y lo actualiza). **Importante:** `cheats.cpp`, `CoreMenu.java` y los `strings_ingame.xml` (en, es)
   que venían en el primer ZIP son de la 0.99.8 y pisaron los de 0.99.10; restáuralos desde tu copia original
   (git o el ZIP del juego) antes de aplicar, o se perderán funciones de 0.99.9/0.99.10.
2. Descomprime este paquete y ejecuta:
   `python3 apply_randomizer_fix.py /ruta/a/CubeEvil4-Android-0.99.10-rc`
   (`--check` solo muestra qué cambiaría). Es idempotente y guarda respaldos en `.randomizer_backup/`.
   Si un ancla no se encuentra, **no escribe nada** y te dice cuál; ver "Edición manual".
3. Comprueba: `python3 tools/check_entity_pool.py .` y `sh port/whole/runtime/tests/run_entity_random_test.sh`.
4. Compila como siempre (`port/tools/whole_build.sh`, Gradle).

## Qué se corrigió
| Problema | Efecto | Corrección |
|---|---|---|
| Archivos de 0.99.8 sobre 0.99.10 | Faltan ~45/74 cadenas (`ingame_bench_*`, `ingame_profile_*`...), falta `re4_story_char_card_items` (error de enlazado, parche 0228) | Restaurar originales y aplicar solo los cambios mínimos con el script |
| Bit 31 dentro de `gWanted` (centinela `< 0`) | Con "Random entities" activo nunca actuaba y se apagaban los otros trucos | El bit 31 va a un atómico aparte (`gEntityOn`); `gWanted` sigue siendo ≥ 0 |
| IDs 0x33 y 0x37 en el catálogo | No tienen módulo propio: se crearía un Ganado con ID erróneo | Excluidos |
| `readEm` deja `Disp_flg = 0xFFFFFFFF` sin ranura libre | Banderas de depuración activadas | Se comprueba la ranura antes y se restaura `Disp_flg` |
| Consumir las 4 ranuras de módulos | Los eventos de la sala podían fallar al cargar | Se deja 1 ranura libre (`RE4_RANDOM_KEEP_FREE_SLOTS`) |
| Un solo intento de reemplazo | Casi siempre caía al enemigo original | Hasta 8 candidatos reproducibles (`RE4_RANDOM_TRIES`) |
| `type` del enemigo original aplicado a otra clase | Variantes inválidas | `type = 0` salvo Ganado→Ganado |
| Semilla compartida con Objetos aleatorios | Apagar uno borraba la semilla del otro | Se conserva mientras uno de los dos esté activo |
| Cadenas solo en en/es | Falta traducción | 11 idiomas |

## Catálogo (42 IDs)
Todo lo que tiene módulo propio entra y puede reemplazar o ser reemplazado: Ganados 0x10–0x17 y 0x19–0x20, perros, cuervo, serpiente, parásito, pez, gallina, murciélagos, trampas, El Gigante, jefes de insecto,
Salazar gigante 0x31, U-3, Mendez, Regenerador, Krauser, jefes 0x38/0x3C, helicópteros/camión (0x3A, 0x3B, 0x3D) y
blancos 0x3E.
**Protegidos:** el mercader (0x18, la tienda siempre está), Del Lago (0x2F) y Saddler (0x30) (`-DRE4_RANDOM_INCLUDE_PROTECTED` los incluye).
**Fuera:** 0x33/0x37/0x3F (sin módulo) y las clases de objeto 0x40+ (puertas, cajas, barriles): no son actores con
módulo y reemplazarlos rompe la progresión. `tools/check_entity_pool.py` lo verifica contra las tablas del juego.

## Límites conocidos (sin probar en dispositivo)
- Solo hay 4 ranuras de módulos de enemigo: la variedad real depende de las que estén libres en cada sala.
- El HP viene de la entrada original de la sala (un Ganado con HP de jefe, o al revés).
- Un reemplazo puede no encajar con los guiones de su sala (jefes con fases, vehículos); conserva una partida de reserva.
- `src/game/em_set.cpp` queda modificado: afecta solo al SHA1 de la compilación GameCube, no al port Android.

## Edición manual (si el script se detiene)
- `cheats.cpp`: quitar `kEntityRandom` del enum y de `kAll`; tras `std::atomic<int> gWanted(-1);` añadir
  `const unsigned kEntityBit = 0x80000000u; std::atomic<int> gEntityOn(0);`; `re4_cheats_set` debe poner
  `gEntityOn` desde `bits & kEntityBit` y guardar `bits & kAll` en `gWanted`; definir
  `extern "C" u8 re4_random_enemy_id(u8, u32, u32, u32 attempt)` (ver el script, constantes `NEW_SET` y `NEW_SELECTOR`).
- `CoreMenu.java`: constantes, `withRandomItems/withRandomEntities` y el interruptor (`NEW_CONSTS`, `NEW_FUNCS`, `NEW_UI`).
- `strings_ingame.xml`: claves `ingame_cheat_random_entities` y `_help` (diccionario `STRINGS`).

## Qué se verificó
Pruebas unitarias del selector, verificador de catálogo contra `EmFileTbl`/módulos, `whole_prepare.py` con los 228
parches, comprobación de sintaxis con g++ de `em_set.cpp` y `cheats.cpp` preparados, XML válido, script idempotente.
**No se compiló** con clang/Gradle ni se probó en juego (no disponibles aquí): confirma con tu build.

## Compilar en GitHub (sin instalar nada en el PC)
Copia `.github/workflows/build-core.yml` y la carpeta `CubeEvil4_Randomizer_Fix/` (este paquete) a tu repositorio
en GitHub; en la pestaña **Actions → Build core APK → Run workflow** compila el núcleo y la APK `core` y la deja como
*artifact* descargable. Si falla, el artifact `build-logs` trae los registros.
