#!/usr/bin/env python3
"""Applies the entity randomizer (corrected) to a CubeEvil4-Android 0.99.10-rc source tree.

    python3 apply_randomizer_fix.py /path/to/CubeEvil4-Android-0.99.10-rc [--check]

Run it on your ORIGINAL 0.99.10 files (or on the tree where the first randomizer ZIP was copied:
it recognises and upgrades that state as well). It is idempotent: a second run changes nothing.

What it does
  1. Copies the files this package owns completely:
       port/whole/runtime/entity_random.h, tests/entity_random_test.cpp, tests/run_entity_random_test.sh,
       src/game/em_set.cpp, tools/check_entity_pool.py
  2. Edits, at text anchors (never by line number), the files it must share with the project:
       port/whole/runtime/cheats.cpp                       (include, switch handling, selector)
       port/android-decomp/.../CoreMenu.java               (bit/seed helpers, switch in the CHEATS page)
       port/android-decomp/app/src/main/res/values*/strings_ingame.xml   (2 strings in 11 languages)
  3. If an anchor is not found the script stops BEFORE writing anything (all edits are computed in
     memory first) and prints what to do by hand (see README_ES.md, section "Edición manual").

Originals are saved once to <root>/.randomizer_backup/ .
"""
import os
import re
import shutil
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
OWNED = [
    "port/whole/runtime/entity_random.h",
    "port/whole/runtime/tests/entity_random_test.cpp",
    "port/whole/runtime/tests/run_entity_random_test.sh",
    "src/game/em_set.cpp",
    "tools/check_entity_pool.py",
]
CHEATS = "port/whole/runtime/cheats.cpp"
MENU = "port/android-decomp/app/src/main/java/com/ast/re4decomp/CoreMenu.java"
RES = "port/android-decomp/app/src/main/res"


class Anchor(Exception):
    pass


def read(path):
    with open(path, encoding="utf-8", errors="surrogateescape", newline="") as f:
        return f.read()


def eol_of(text):
    return "\r\n" if "\r\n" in text else "\n"


# ----------------------------------------------------------------------------------------- cheats.cpp
NEW_SET = '''void re4_cheats_set(int bits)
{
    // Bit 31 ("Random entities") is kept out of gWanted, see gEntityOn.
    const int entity = ((unsigned) bits & kEntityBit) != 0 ? 1 : 0;
    if (gEntityOn.exchange(entity, std::memory_order_acq_rel) != entity) {
        re4_log("cheat: random entities %s (seed %u), from the next room on", entity ? "on" : "off",
                (unsigned) ((u32) (bits & kSeedMask) >> kSeedShift));
    }
    gWanted.store(bits & kAll, std::memory_order_release);
}'''

NEW_SELECTOR = '''// ---- random entities (src/game/em_set.cpp asks for every enemy a room creates) ------------------------------
// The switch (bit 31 of the app's cheat switches; the seed is the items' one, bits 11..30) replaces what the
// room lists create by another actor of the pool in port/whole/runtime/entity_random.h: the same list entry
// gets the same actor for the same seed. `attempt` 0 is the first choice; em_set.cpp asks for further ones
// when a candidate's module cannot be loaded (only 4 module slots exist). Story only (not Ashley's part,
// Assignment Ada, The Mercenaries). Unchanged: ids outside the pool (merchant, Del Lago, Saddler ...).
extern "C" u8 re4_random_enemy_id(u8 original, u32 room_key, u32 entry_key, u32 attempt)
{
    if (!gEntityOn.load(std::memory_order_acquire) || !storyGame() || pG->pl_type == 1) {
        return original;
    }
    const u32 seed = (u32) (wantedBits() & kSeedMask) >> kSeedShift;
    return re4_random_entity_id(original, seed, room_key, entry_key, attempt);
}
'''

ENTITY_DECL = '''// "Random entities" is bit 31 of the switches. It must NOT live in gWanted: that word is negative while
// RE4_CHEATS has not been read (wantedBits, hook, re4_invisible, re4_cheats_wanted all test `< 0`), so a
// sign bit inside it made every switch look "unset" (and the randomizer never ran). re4_cheats_set keeps it
// here and masks it out of gWanted.
const unsigned kEntityBit = 0x80000000u;
std::atomic<int> gEntityOn(0);
'''


def balanced_end(text, open_idx):
    """index just after the '}' that closes the '{' at open_idx."""
    depth = 0
    i = open_idx
    while i < len(text):
        c = text[i]
        if c == "{":
            depth += 1
        elif c == "}":
            depth -= 1
            if depth == 0:
                return i + 1
        i += 1
    raise Anchor("unbalanced braces")


def edit_cheats(text):
    nl = eol_of(text)
    t = text.replace("\r\n", "\n")

    # 1. include
    if '#include "entity_random.h"' not in t:
        if '#include "pl_npc.h"\n' not in t:
            raise Anchor('cheats.cpp: `#include "pl_npc.h"` not found')
        t = t.replace('#include "pl_npc.h"\n', '#include "pl_npc.h"\n#include "entity_random.h"\n', 1)

    # 2. the first randomizer put the switch into the enum and into kAll: take it out
    t = re.sub(r"kEntityRandom\s*=\s*\(int\)\s*0x80000000u,\s*", "", t)
    t = re.sub(r"\s*\|\s*kEntityRandom\b", "", t)
    if "kSeedMask" not in t or "kSeedShift" not in t:
        raise Anchor("cheats.cpp: kSeedMask / kSeedShift (the item seed) not found")

    # 3. gEntityOn next to gWanted
    if "gEntityOn" not in t:
        m = re.search(r"std::atomic<int> gWanted\(-1\);[^\n]*\n", t)
        if not m:
            raise Anchor("cheats.cpp: `std::atomic<int> gWanted(-1);` not found")
        t = t[:m.end()] + ENTITY_DECL + t[m.end():]
    elif "kEntityBit" not in t:
        raise Anchor("cheats.cpp: gEntityOn exists without kEntityBit")

    # 4. re4_cheats_set
    m = re.search(r"void re4_cheats_set\(int bits\)\s*\{", t)
    if not m:
        raise Anchor("cheats.cpp: `void re4_cheats_set(int bits)` not found")
    end = balanced_end(t, m.end() - 1)
    t = t[:m.start()] + NEW_SET + t[end:]

    # 5. the selector: remove the first randomizer's, insert ours before the `extern "C" {` of patch 0218
    m = re.search(r"(?://[^\n]*\n)*extern \"C\" u8 re4_random_enemy_id\([^)]*\)\s*\{", t)
    if m:
        end = balanced_end(t, m.end() - 1)
        while t[end:end + 1] == "\n":
            end += 1
        t = t[:m.start()] + t[end:]
    m = re.search(r"\nextern \"C\" \{\n\n// Patch 0218", t)
    if m:
        t = t[:m.start() + 1] + NEW_SELECTOR + t[m.start():]
    else:
        # the layout of the real file differs: the selector only needs file scope after the anonymous
        # namespace (storyGame, wantedBits, kSeedMask ...), so it goes at the very end
        t = t.rstrip("\n") + "\n\n" + NEW_SELECTOR
    if "kEntityRandom" in t:
        raise Anchor("cheats.cpp: an unexpected use of kEntityRandom remains")
    return t.replace("\n", nl)


# ----------------------------------------------------------------------------------------- CoreMenu.java
NEW_CONSTS = '''static final int RANDOM_ITEMS_BIT = 1024, RANDOM_ENTITIES_BIT = 0x80000000,
      SEED_SHIFT = 11, SEED_BITS = 0xFFFFF << SEED_SHIFT;'''

NEW_FUNCS = '''  /** The cheat switches with "Random items" on (with `seed`, 0 .. 2^20 - 1) or off (no seed). "Random entities"
   *  shares the seed: while that switch is on the seed stays, so both deal from the same one. */
  static int withRandomItems(int bits, boolean on, int seed) {
    bits &= ~RANDOM_ITEMS_BIT;
    if (on) {
      if ((bits & RANDOM_ENTITIES_BIT) != 0 && (bits & SEED_BITS) != 0) return bits | RANDOM_ITEMS_BIT;
      return (bits & ~SEED_BITS) | RANDOM_ITEMS_BIT | ((seed << SEED_SHIFT) & SEED_BITS);
    }
    return (bits & RANDOM_ENTITIES_BIT) != 0 ? bits : bits & ~SEED_BITS;
  }
  /** The cheat switches with "Random entities" (bit 31) on or off; same reproducible seed as the items. */
  static int withRandomEntities(int bits, boolean on, int seed) {
    bits &= ~RANDOM_ENTITIES_BIT;
    if (on) {
      if ((bits & RANDOM_ITEMS_BIT) == 0) bits = (bits & ~SEED_BITS) | ((seed << SEED_SHIFT) & SEED_BITS);
      return bits | RANDOM_ENTITIES_BIT;
    }
    return (bits & RANDOM_ITEMS_BIT) != 0 ? bits : bits & ~SEED_BITS;
  }
'''

NEW_UI = '''    MenuLayout.Buttons entities = cheatRow(2);
    toggle(entities, R.string.ingame_cheat_random_entities, (cheatBits & RANDOM_ENTITIES_BIT) != 0, on -> {
      cheatBits = withRandomEntities(cheatBits, on, new java.util.Random().nextInt(1 << 20));
      host.cheatsChanged(cheatBits);
    });
    help(R.string.ingame_cheat_random_entities_help);
'''


def edit_menu(text):
    nl = eol_of(text)
    t = text.replace("\r\n", "\n")

    # constants
    m = re.search(r"static final int RANDOM_ITEMS_BIT = 1024,\s*(?:RANDOM_ENTITIES_BIT = 0x80000000,\s*)?"
                  r"SEED_SHIFT = 11,\s*SEED_BITS = 0xFFFFF << SEED_SHIFT;", t)
    if not m:
        raise Anchor("CoreMenu.java: the RANDOM_ITEMS_BIT / SEED_SHIFT / SEED_BITS constants not found")
    t = t[:m.start()] + NEW_CONSTS + t[m.end():]

    # helper functions: from the javadoc of withRandomItems to the end of withRandomEntities (when present)
    m = re.search(r"static int withRandomItems\(int bits, boolean on, int seed\)\s*\{", t)
    if not m:
        raise Anchor("CoreMenu.java: `static int withRandomItems(` not found")
    end = balanced_end(t, m.end() - 1)
    start = t.rfind("  /**", 0, m.start())
    if start < 0 or t[start:m.start()].count("*/") != 1:
        raise Anchor("CoreMenu.java: the javadoc of withRandomItems not found")
    m2 = re.match(r"\s*(?:/\*\*[^\n]*\*/\s*)?static int withRandomEntities\(int bits, boolean on, int seed\)\s*\{", t[end:])
    if m2:
        end = end + balanced_end(t[end:], m2.end() - 1)
    end = end + 1 if t[end:end + 1] == "\n" else end
    t = t[:start] + NEW_FUNCS + t[end:]

    # the switch in the CHEATS page
    m = re.search(r"    MenuLayout\.Buttons entities = cheatRow\(2\);.*?"
                  r"help\(R\.string\.ingame_cheat_random_entities_help\);\n", t, re.S)
    if m:
        t = t[:m.start()] + NEW_UI + t[m.end():]
    else:
        m = re.search(r"    help\(R\.string\.ingame_cheat_random_items_help\);\n", t)
        if not m:
            raise Anchor("CoreMenu.java: `help(R.string.ingame_cheat_random_items_help);` not found")
        t = t[:m.end()] + NEW_UI + t[m.end():]
    return t.replace("\n", nl)


# ----------------------------------------------------------------------------------------- strings
STRINGS = {
    "values": (
        "Random entities",
        "Random entities: in the story every enemy the rooms create is replaced by another enemy, animal, trap, "
        "sub-boss or boss, dealt from a repeatable seed (shared with Random items; a new one each time a switch "
        "goes on). Takes effect from the next room on. Merchants, Del Lago, Saddler and the giant Salazar stay as "
        "they are. Experimental: a replacement does not always suit its room\\'s scripts, so keep a spare save."),
    "values-es": (
        "Entidades aleatorias",
        "Entidades aleatorias: en la historia, cada enemigo que crean las salas se sustituye por otro enemigo, "
        "animal, trampa, subjefe o jefe, según una semilla reproducible (la misma de Objetos aleatorios; una nueva "
        "cada vez que se activa un interruptor). Se aplica desde la sala siguiente. Los mercaderes, Del Lago, "
        "Saddler y el Salazar gigante no cambian. Experimental: una sustitución no siempre encaja con los guiones "
        "de su sala, así que conserva una partida de reserva."),
    "values-de": (
        "Zufällige Gegner",
        "Zufällige Gegner: In der Geschichte wird jeder Gegner, den die Räume erzeugen, durch einen anderen Gegner, "
        "ein Tier, eine Falle, einen Zwischen- oder Endgegner ersetzt, nach einem wiederholbaren Startwert (derselbe "
        "wie bei Zufällige Gegenstände; bei jedem Einschalten ein neuer). Gilt ab dem nächsten Raum. Händler, Del "
        "Lago, Saddler und der riesige Salazar bleiben unverändert. Experimentell: Ein Ersatz passt nicht immer zu "
        "den Skripten seines Raums, also einen Reservespielstand behalten."),
    "values-fr": (
        "Entités aléatoires",
        "Entités aléatoires : dans l\\'histoire, chaque ennemi créé par les salles est remplacé par un autre "
        "ennemi, animal, piège, sous-boss ou boss, tiré d\\'une graine reproductible (la même que pour Objets "
        "aléatoires ; une nouvelle à chaque activation). Effet dès la salle suivante. Les marchands, Del Lago, "
        "Saddler et le Salazar géant ne changent pas. Expérimental : un remplaçant ne convient pas toujours aux "
        "scripts de sa salle, gardez une sauvegarde de secours."),
    "values-it": (
        "Entità casuali",
        "Entità casuali: nella storia ogni nemico creato dalle stanze viene sostituito da un altro nemico, "
        "animale, trappola, sotto-boss o boss, estratto da un seme ripetibile (lo stesso di Oggetti casuali; "
        "uno nuovo a ogni attivazione). Vale dalla stanza successiva. Mercanti, Del Lago, Saddler e il Salazar "
        "gigante restano invariati. Sperimentale: una sostituzione non sempre si adatta agli script della stanza, "
        "tieni un salvataggio di riserva."),
    "values-pt": (
        "Entidades aleatórias",
        "Entidades aleatórias: na história, cada inimigo criado pelas salas é substituído por outro inimigo, "
        "animal, armadilha, subchefe ou chefe, sorteado com uma semente repetível (a mesma de Itens aleatórios; "
        "uma nova a cada ativação). Vale a partir da próxima sala. Comerciantes, Del Lago, Saddler e o Salazar "
        "gigante não mudam. Experimental: um substituto nem sempre combina com os scripts da sala, mantenha um "
        "save de reserva."),
    "values-ru": (
        "Случайные сущности",
        "Случайные сущности: в сюжете каждый противник, которого создают комнаты, заменяется другим противником, "
        "животным, ловушкой, мини-боссом или боссом по повторяемому зерну (то же, что у случайных предметов; "
        "новое при каждом включении). Действует со следующей комнаты. Торговцы, Дель Лаго, Саддлер и гигантский "
        "Салазар не меняются. Экспериментально: замена не всегда подходит скриптам комнаты, держите запасное "
        "сохранение."),
    "values-zh": (
        "随机实体",
        "随机实体：在剧情中，房间生成的每个敌人都会被另一个敌人、动物、陷阱、小Boss或Boss替换，使用可重复的种子"
        "（与随机物品共用；每次开启开关都会换新种子）。从下一个房间起生效。商人、Del Lago、Saddler和巨型Salazar"
        "保持不变。实验性功能：替换对象不一定适合房间脚本，请保留备用存档。"),
    "values-hi": (
        "यादृच्छिक इकाइयाँ",
        "यादृच्छिक इकाइयाँ: कहानी में कमरे जो भी दुश्मन बनाते हैं, उसे किसी दूसरे दुश्मन, जानवर, जाल, उप-बॉस या बॉस से "
        "बदला जाता है, दोहराए जा सकने वाले सीड से (यादृच्छिक आइटम वाला ही; हर बार चालू करने पर नया)। अगले कमरे से लागू "
        "होता है। व्यापारी, Del Lago, Saddler और विशाल Salazar नहीं बदलते। प्रायोगिक: बदला हुआ पात्र कमरे की स्क्रिप्ट "
        "से हमेशा मेल नहीं खाता, इसलिए एक अतिरिक्त सेव रखें।"),
    "values-in": (
        "Entitas acak",
        "Entitas acak: dalam cerita, setiap musuh yang dibuat ruangan diganti dengan musuh, hewan, jebakan, sub-bos "
        "atau bos lain berdasarkan seed yang dapat diulang (sama dengan Item acak; baru setiap kali sakelar "
        "diaktifkan). Berlaku mulai ruangan berikutnya. Pedagang, Del Lago, Saddler, dan Salazar raksasa tidak "
        "berubah. Eksperimental: pengganti tidak selalu cocok dengan skrip ruangan, simpan save cadangan."),
    "values-ar": (
        "كيانات عشوائية",
        "كيانات عشوائية: في القصة يُستبدل كل عدو تنشئه الغرف بعدو أو حيوان أو فخ أو زعيم فرعي أو زعيم آخر وفق بذرة "
        "قابلة للتكرار (نفسها في العناصر العشوائية؛ وتتجدد عند كل تشغيل). يسري من الغرفة التالية. التجار وDel Lago "
        "وSaddler وSalazar العملاق لا يتغيرون. تجريبي: قد لا يناسب البديل نصوص الغرفة دائماً، فاحتفظ بحفظ احتياطي."),
}


def edit_strings(path, folder):
    text = read(path)
    nl = eol_of(text)
    t = text.replace("\r\n", "\n")
    title, help_ = STRINGS[folder]
    t = re.sub(r'[ \t]*<string name="ingame_cheat_random_entities(?:_help)?">.*?</string>\n', "", t, flags=re.S)
    m = re.search(r'([ \t]*)<string name="ingame_cheat_random_items_help">.*?</string>\n', t, re.S)
    if not m:
        raise Anchor("%s: `ingame_cheat_random_items_help` not found" % path)
    ind = m.group(1)
    new = '%s<string name="ingame_cheat_random_entities">%s</string>\n%s<string name="ingame_cheat_random_entities_help">%s</string>\n' % (
        ind, title, ind, help_)
    t = t[:m.end()] + new + t[m.end():]
    return t.replace("\n", nl)


# ----------------------------------------------------------------------------------------- main
def main():
    args = [a for a in sys.argv[1:] if not a.startswith("--")]
    check_only = "--check" in sys.argv
    if len(args) != 1:
        print(__doc__)
        return 2
    root = os.path.abspath(args[0])
    for need in ("src/game/em_set.cpp", CHEATS, MENU):
        if not os.path.isfile(os.path.join(root, need)):
            print("not a CubeEvil4 source tree (missing %s): %s" % (need, root))
            return 2

    planned = {}   # path -> new text
    errors = []

    def attempt(rel, fn, *a):
        try:
            planned[rel] = fn(*a)
        except Anchor as e:
            errors.append((rel, str(e)))

    attempt(CHEATS, lambda: edit_cheats(read(os.path.join(root, CHEATS))))
    attempt(MENU, lambda: edit_menu(read(os.path.join(root, MENU))))
    for folder in STRINGS:
        rel = "%s/%s/strings_ingame.xml" % (RES, folder)
        if os.path.isfile(os.path.join(root, rel)):
            attempt(rel, lambda r=rel, f=folder: edit_strings(os.path.join(root, r), f))
        else:
            print("note: %s does not exist, skipped" % rel)
    if errors:
        print("STOPPED, nothing written. %d file(s) did not match:" % len(errors))
        for rel, msg in errors:
            print("  - " + msg)
        print("--- diagnostics (what the real files contain at the anchors) ---")
        for rel, pat in ((CHEATS, r're4_cheats_set|Patch 02|^extern "C"|gWanted\(|kSeedMask|namespace'),
                         (MENU, r'RANDOM_ITEMS_BIT|SEED_SHIFT|withRandomItems|random_items')):
            fp = os.path.join(root, rel)
            if os.path.isfile(fp):
                print("[%s]" % rel)
                shown = 0
                for n, line in enumerate(read(fp).split("\n"), 1):
                    if re.search(pat, line):
                        print("  %5d: %s" % (n, line[:150]))
                        shown += 1
                        if shown >= 40:
                            break
        print("Make these edits by hand (README_ES.md, 'Edición manual') and run the script again.")
        return 1

    changed = []
    for rel, new in planned.items():
        if read(os.path.join(root, rel)) != new:
            changed.append(rel)
    owned_changed = [rel for rel in OWNED
                     if not os.path.isfile(os.path.join(root, rel))
                     or read(os.path.join(root, rel)) != read(os.path.join(HERE, rel))]
    if check_only:
        print("would change: %s" % (", ".join(changed + owned_changed) or "nothing (already applied)"))
        return 0

    backup = os.path.join(root, ".randomizer_backup")
    for rel in changed + owned_changed:
        src = os.path.join(root, rel)
        if os.path.isfile(src):
            dst = os.path.join(backup, rel)
            if not os.path.exists(dst):
                os.makedirs(os.path.dirname(dst), exist_ok=True)
                shutil.copy2(src, dst)
    for rel in changed:
        with open(os.path.join(root, rel), "w", encoding="utf-8", errors="surrogateescape", newline="") as f:
            f.write(planned[rel])
    for rel in owned_changed:
        dst = os.path.join(root, rel)
        os.makedirs(os.path.dirname(dst), exist_ok=True)
        shutil.copyfile(os.path.join(HERE, rel), dst)
        if rel.endswith(".sh"):
            os.chmod(dst, 0o755)
    print("changed: " + (", ".join(changed + owned_changed) or "nothing (already applied)"))
    if changed or owned_changed:
        print("originals saved in %s" % backup)
    return 0


if __name__ == "__main__":
    sys.exit(main())
