// game/em_set.cpp: enemy creation from the room enemy list (ESL) in pG->Em_list. Killed list enemies
// are recorded in the pG->Em_flg bit tables so they stay dead when the room is re-entered.

#include "atari.h"
#include "light.h"
#include "em_set.h"
#include "global.h"
#include "db_log.h"
#include "em.h"
#include "player.h"
#include "read.h"

// PORT (entity randomizer: port/whole/runtime/cheats.cpp + entity_random.h + entity_random_protect.h).
// Randomized: the enemies a room's list creates when the room loads (EmSetFromList), the ones scripts take by list
// number (EmSetFromList2) and the ones events create (EmSetEvent, e.g. the waves of the village raid). Only the
// first zone stays vanilla. Scripts that cast what they get back may not like a replacement: if a room misbehaves
// the log names it ("random: room 0x....") and entity_random.h (RE4_NEVER_ROOMS) turns it off.
extern "C" void re4_log(const char* fmt, ...);
extern "C" int re4_random_begin_room(u32 room_id);                         // 1: randomize this room load
extern "C" int re4_random_pool_size(void);
extern "C" u8 re4_random_pool_id(int i);
extern "C" u32 re4_random_hash(u32 a, u32 b, u32 c);                       // seeded, reproducible
extern "C" int re4_random_replaceable(u32 room_id, u32 entry, u8 original); // in the pool, no script holds it
extern "C" int re4_random_event_replaceable(u32 room_id, u8 original);      // event enemy: in the pool, room ignores the object

cEm* errEm = 0;
static int emSetDummy = 0;

// Death bit of list entry `no` in the current enemy list (0 when no list is loaded).
// Death bit of list entry `no` in the current list (pG->em_list_no); 0 when no list is loaded.
static inline u32 EmSetDieCk(u32 no)
{
    u32 v;

    if (pG->em_list_no >= 0) {
        u32* tbl = EM_FLG_ROW(pG->em_list_no);

        v = tbl[no >> 5] & (0x80000000 >> (no & 31));
    } else {
        v = 0;
    }
    return v;
}

// Sets the death bit of list entry `no` in the current list.
static inline void EmSetDieOn(u32 no)
{
    if (pG->em_list_no >= 0) {
        u32* tbl = EM_FLG_ROW(pG->em_list_no);

        tbl[no >> 5] |= 0x80000000 >> (no & 31);
    }
}


// While flags_68 bit21 is set only the enemies 3 and 4 may be created.
#define EM_SET_ID_NG(id) (DbgFlagChk(pG, DBG_NO_ENEMY) && ((id) != 3 && (id) != 4))

// Pulls an enemy work for `id`: the partner (0xF) and the parasite (0x25) are created at the back
// of the pool so they move after the others.
static inline cEm* EmCreate(u8 id)
{
    if (id == 0xF || id == 0x25) {
        return EmMgr.createBack(id);
    }
    return EmMgr.create(id);
}

// ---- entity randomizer (port) ------------------------------------------------------------------------
// Each time a room loads (EmSetFromList runs once per room load, after the room's init function has loaded
// the modules it needs) a "palette" is made: the pool's modules that are already loaded plus up to
// RE4_RANDOM_MAX_NEW further ones from the whole pool (any chapter: castle, island ...), loaded right here,
// at room-load time like the room's own modules. The room's list entries then draw from the palette; every
// room load uses a new draw (sRoomLoad), so a reload or a checkpoint gives other enemies. Nothing is loaded
// afterwards: while the room runs, only modules that are loaded are used, and the original actor is created
// when a draw cannot be served. 4 module slots exist: RE4_RANDOM_KEEP_FREE_SLOTS stay free for the room.
#ifndef RE4_RANDOM_KEEP_FREE_SLOTS
#define RE4_RANDOM_KEEP_FREE_SLOTS 1
#endif
#ifndef RE4_RANDOM_MAX_NEW
#define RE4_RANDOM_MAX_NEW 3
#endif
#define RE4_RANDOM_PALETTE_MAX 48

static u8 sPalette[RE4_RANDOM_PALETTE_MAX];
static int sPaletteN = 0;
static int sPaletteNew = 0;    // palette[sPaletteNew..] are the modules this room load added (not the room's own)
static u32 sRoomLoad = 0;
static u32 sPaletteRoom = 0xFFFFFFFF;   // the room the palette was made for

static int EmRandomFreeSlots(void)
{
    int i;
    int n = 0;

    for (i = 0; i < RE4_EM_SLOTS; i++) {
        if (EmReadModule[i].pData == 0) {
            n++;
        }
    }
    return n;
}

static int EmRandomInPalette(u8 id)
{
    int i;

    for (i = 0; i < sPaletteN; i++) {
        if (sPalette[i] == id) {
            return 1;
        }
    }
    return 0;
}

static void EmRandomBeginRoom(void)
{
    const u32 room = ((u32) pG->stage_no << 8) | pG->room_no;
    int pool;
    int i;
    int want;
    u32 tries;

    sPaletteN = 0;
    sPaletteNew = 0;
    sRoomLoad++;
    sPaletteRoom = room;
    if (!re4_random_begin_room(room)) {
        return;
    }
    pool = re4_random_pool_size();
    for (i = 0; i < pool && sPaletteN < RE4_RANDOM_PALETTE_MAX; i++) {
        u8 id = re4_random_pool_id(i);
        if (SearchEmModule(id) != 0) {
            sPalette[sPaletteN++] = id;
        }
    }
    sPaletteNew = sPaletteN;
    want = EmRandomFreeSlots() - RE4_RANDOM_KEEP_FREE_SLOTS;
    if (want > RE4_RANDOM_MAX_NEW) {
        want = RE4_RANDOM_MAX_NEW;
    }
    for (tries = 0; want > 0 && tries < 24 && sPaletteN < RE4_RANDOM_PALETTE_MAX; tries++) {
        u8 id = re4_random_pool_id((int) (re4_random_hash(room, sRoomLoad, 0x100 + tries) % (u32) pool));
        u32 disp;
        void* mod;

        if (EmRandomInPalette(id) || EmRandomFreeSlots() <= RE4_RANDOM_KEEP_FREE_SLOTS) {
            continue;
        }
        re4_log("random: room 0x%04x load %u: loading module 0x%02x", room, sRoomLoad, id);
        disp = pG->Disp_flg;
        mod = EmReadSearch(id, 0, 0);   // what the room scripts and EmCreate do
        pG->Disp_flg = disp;
        if (mod != 0) {
            sPalette[sPaletteN++] = id;
            want--;
        }
    }
    re4_log("random: room 0x%04x load %u: %d actors in the palette, %d module slots free", room, sRoomLoad, sPaletteN,
            EmRandomFreeSlots());
}

// Creates the enemy for list entry (room_key, entry_key) of original id `original`: one from the room's
// palette (only loaded modules, so nothing is loaded here), else the original. event: created by EmSetEvent
// (room_key is then the current room). *spawnId = what was created.
static cEm* EmCreateRandom(u8 original, u32 room_key, u32 entry_key, int event, u8* spawnId)
{
    u32 attempt;

    // a palette is only valid in the room it was made for (a script of a room that is just loading may create
    // enemies before EmSetFromList has made that room's palette)
    if (sPaletteN > 0 && sPaletteRoom == (((u32) pG->stage_no << 8) | pG->room_no) &&
        (event ? re4_random_event_replaceable(room_key, original)
                                : re4_random_replaceable(room_key, entry_key, original))) {
        for (attempt = 0; attempt < 4 && sPaletteN > 0; attempt++) {
            // every room load (reload, checkpoint, coming back) mixes its own number in: a new draw, as with a new seed
            const u32 h = re4_random_hash(room_key ^ (sRoomLoad * 0x9E3779B1u), entry_key, attempt);
            u8 cand;
            cEm* em;
            u32 disp;

            // when this load added modules from other chapters, most draws come from them
            if (sPaletteNew < sPaletteN && (h & 3) != 0) {
                cand = sPalette[sPaletteNew + (h >> 2) % (u32) (sPaletteN - sPaletteNew)];
            } else {
                cand = sPalette[(h >> 2) % (u32) sPaletteN];
            }
            if (cand == original) {
                break;
            }
            if (SearchEmModule(cand) == 0) {   // gone (a script re-initialised the modules): not usable
                continue;
            }
            disp = pG->Disp_flg;
            em = EmCreate(cand);
            pG->Disp_flg = disp;
            if (em != 0) {
                re4_log("random: room 0x%04x load %u entry %u: 0x%02x -> 0x%02x", room_key, sRoomLoad, entry_key,
                        original, cand);
                *spawnId = cand;
                return em;
            }
        }
    }
    *spawnId = original;
    return EmCreate(original);
}

// A substituted actor keeps the list entry's data (position, hp ...) but `type` selects a model/variant
// inside the class, so it is only meaningful when the class is the same (Ganado -> Ganado). Anything else
// starts with variant 0, which every class has.
static inline void EmSetSubstituteType(cEm* em, u8 original, u8 spawnId)
{
    if (spawnId != original && !(original >= 0x10 && original <= 0x20 && original != 0x18 &&
                                 spawnId >= 0x10 && spawnId <= 0x20 && spawnId != 0x18)) {
        em->type = 0;
    }
}

// Copy the list entry into the fresh enemy work.
static inline void EmSetWork(cEm* em, EM_LIST* d, u8 no)
{
    f32 kx = 1000.0f;
    f32 kr = 3.1415927f / 16384.0f;
    f32 kp = 10.0f;

    em->type = d->type;
    em->set = d->set;
    em->flag = d->flag;
    em->Character = d->Character;
    em->Guard_r = (f32) d->Guard_r * kx;
    em->hp_max = em->hp = d->hp;
    em->ang.x = (f32) d->rot[0] * kr;
    em->ang.y = (f32) d->rot[1] * kr;
    em->ang.z = (f32) d->rot[2] * kr;
    em->pos.x = (f32) d->pos[0] * kp;
    em->pos.y = (f32) d->pos[1] * kp;
    em->pos.z = (f32) d->pos[2] * kp;
    em->pos_old = em->pos;
    em->emset_no = no;
}

// The same body as a macro for the two straight-line creators (EmSetFromList2, EmSetEvent): its pool
// loads keep RTX_UNCHANGING_P, which integrate.c drops for an inlined body, and schedule like the
// original. The loop in EmSetFromList keeps the inline.
#define EM_SET_WORK(em, d, no)                                                            \
    do {                                                                                  \
        f32 kx = 1000.0f;                                                                 \
        f32 kr = 3.1415927f / 16384.0f;                                                   \
        f32 kp = 10.0f;                                                                   \
        (em)->type = (d)->type;                                                           \
        (em)->set = (d)->set;                                                             \
        (em)->flag = (d)->flag;                                                    \
        (em)->Character = (d)->Character;                                                             \
        (em)->Guard_r = (f32) (d)->Guard_r * kx;                                                 \
        (em)->hp_max = (em)->hp = (d)->hp;                                                 \
        (em)->ang.x = (f32) (d)->rot[0] * kr;                                             \
        (em)->ang.y = (f32) (d)->rot[1] * kr;                                             \
        (em)->ang.z = (f32) (d)->rot[2] * kr;                                             \
        (em)->pos.x = (f32) (d)->pos[0] * kp;                                             \
        (em)->pos.y = (f32) (d)->pos[1] * kp;                                             \
        (em)->pos.z = (f32) (d)->pos[2] * kp;                                             \
        (em)->pos_old = (em)->pos;                                                         \
        (em)->emset_no = (no);                                                             \
    } while (0)

// Squared XZ distance to the player. The `x374 = 1e16` reset is a caller statement after this call
// because inside the inline its pool load loses RTX_UNCHANGING_P (see above), is scheduled one insn
// too early and does not get f12.
static inline void EmSetDist(cEm* em)
{
    f32 dz = pPL->pos.z - em->pos.z;
    f32 dx = pPL->pos.x - em->pos.x;

    em->l_pl = dx * dx + dz * dz;
}


// 1 when no live enemy already carries list entry `no` (0xFF: always 1).
int checkListId(int no)
{
    u32 i;

    if (no == 0xFF) {
        return 1;
    }
    for (i = 0; i < EmMgr.getArrayNum(); i++) {
        cEm* em = EmMgr.at(i);

        if (em->isAlive() && em->emset_no == (u8) no) {
            return 0;
        }
    }
    return 1;
}

// Room start: creates every list entry that is alive (be_flag bit0), not yet set (bit1), not
// recorded dead, belongs to the current stage / room, has an id and is not blocked by the debug
// filter; copies the entry into the work, marks it set (bit1, toggling bits 2/3), computes the
// player distance and runs the first move.
void EmSetFromList()
{
    u32 i;

    EmRandomBeginRoom();
    for (i = 0; i < 256; i++) {
        EM_LIST* d = &pG->Em_list[i];
        cEm* em;
        u8 spawnId;

        if (!(d->be_flag & 1)) {
            continue;
        }
        if (d->be_flag & 2) {
            continue;
        }
        if (EmSetDieCk(i)) {
            continue;
        }
        if (pG->stage_no != d->room >> 8) {
            continue;
        }
        if (pG->room_no != (d->room & 0xFF)) {
            continue;
        }
        if (checkListId(i) == 0) {
            continue;
        }
        // d->id read directly: the range fold of EM_SET_ID_NG keeps the QImode load and the int
        // uses share one PRE'd `clrlwi`; a `u8 id` local is promoted and never masked.
        if (d->id == 0) {
            continue;
        }
        if (EM_SET_ID_NG(d->id)) {
            continue;
        }
        em = EmCreateRandom(d->id, d->room, i, 0, &spawnId);
        if (em == 0) {
            pLog->err(0, 0, "EmSetFromList() Em set failed, Id = %x", spawnId);
            continue;
        }
        EmSetWork(em, d, i);
        EmSetSubstituteType(em, d->id, spawnId);
        d->be_flag |= 2;
        if (d->be_flag & 4) {
            d->be_flag |= 8;
            d->be_flag &= ~4;
        } else if (!(d->be_flag & 8)) {
            d->be_flag |= 4;
        }
        EmSetDist(em);
        em->l_sub = 1.0e16f;
        em->move();
    }
}

// Creates list entry `no` on demand (room event scripts): same checks as EmSetFromList, the
// death bit only with chkDead. Returns the enemy, or errEm when nothing was created.
cEm* EmSetFromList2(int no, int flag)
{
    EM_LIST* d = &pG->Em_list[no];
    cEm* em;
    u8 spawnId;

    if (EM_SET_ID_NG(d->id)) {
        return errEm;
    }
    if (pG->stage_no != d->room >> 8) {
        return errEm;
    }
    if (pG->room_no != (d->room & 0xFF)) {
        return errEm;
    }
    if (d->be_flag & 2) {
        return errEm;
    }
    if (d->id == 0) {
        return errEm;
    }
    if (flag) {
        if (EmSetDieCk(no)) {
            return errEm;
        }
    }
    if (checkListId(no) == 0) {
        return errEm;
    }
    em = EmCreateRandom(d->id, d->room, (u32) no, 0, &spawnId);
    if (em == 0) {
        pLog->err(0, 0, "EmSetFromList2() Em set failed, Id = %x", spawnId);
        return errEm;
    }
    EM_SET_WORK(em, d, no);
    EmSetSubstituteType(em, d->id, spawnId);
    d->be_flag |= 2;
    if (d->be_flag & 4) {
        d->be_flag |= 8;
        d->be_flag &= ~4;
    } else if (!(d->be_flag & 8)) {
        d->be_flag |= 4;
    }
    EmSetDist(em);
    em->l_sub = 1.0e16f;
    em->move();
    return em;
}

// Event enemy from a list entry outside the room list (never called in the DOL).
cEm* EmSetEvent(EM_LIST* d)
{
    cEm* em;

    if (EM_SET_ID_NG(d->id)) {
        return errEm;
    }
    {
        // an event's list entry has no room of its own: the current room is the key, the position the entry
        const u32 room = ((u32) pG->stage_no << 8) | pG->room_no;
        const u32 entryKey = (u16) d->pos[0] ^ ((u32) (u16) d->pos[1] << 10) ^ ((u32) (u16) d->pos[2] << 20);
        u8 spawnId;

        em = EmCreateRandom(d->id, room, entryKey, 1, &spawnId);
        if (em == 0) {
            pLog->err(0, 0, "EmSetEvent() Em set failed, Id = %x", spawnId);
            return errEm;
        }
        EM_SET_WORK(em, d, 0xFF);
        EmSetSubstituteType(em, d->id, spawnId);
    }
    d->be_flag = 7;
    EmSetDist(em);
    em->l_sub = 1.0e16f;
    em->move();
    return em;
}

// The live enemy created from list entry `no`; NULL when none (or no == 0xFF).
cEm* GetEmPtrFromList(int no)
{
    u32 i;

    if (no == 0xFF) {
        return 0;
    }
    for (i = 0; i < EmMgr.getArrayNum(); i++) {
        cEm* em = EmMgr.at(i);

        if (em->isAlive() && em->emset_no == (u8) no) {
            return em;
        }
    }
    return 0;
}

// The list entry an enemy was created from; NULL for enemies not from the list (emset_no 0xFF).
EM_LIST* GetListPtrFromEm(cEm* em)
{
    if (em->emset_no == 0xFF) {
        return 0;
    }
    return &pG->Em_list[em->emset_no];
}

// Enemy id of list entry `no` (0xFF for an invalid index).
u32 GetEmIdFromList(u32 no)
{
    EM_LIST* list;

    if (no >= 0xFF) {
        return 0xFF;
    }
    list = pG->Em_list;
    return list[no].id;
}

// Sets / clears the alive bit (be_flag bit0) of list entry `no`, only for entries of the current
// stage / room.
void EmListSetAlive(int no, int on_off)
{
    EM_LIST* d = &pG->Em_list[no];

    if (pG->stage_no != d->room >> 8) {
        return;
    }
    if (pG->room_no != (d->room & 0xFF)) {
        return;
    }
    if (on_off == 1) {
        d->be_flag |= 1;
    } else {
        d->be_flag &= ~1;
    }
}

// Records the death of a list enemy in the current death bit table (so it is not re-created),
// except in stage 4 rooms and under the debug flags that keep enemies respawning.
void EmSetDie(cEm* em)
{
    if (DbgFlagChk(pG, DBG_NO_SCE_EXE)) {
        return;
    }
    if (pG->stage_no == 0 && pG->room_no == 4) {
        return;
    }
    if (DbgFlagChk(pG, DBG_EM_NO_DIE_FLAG)) {
        return;
    }
    if (EmSetDieCk(em->emset_no)) {
        return;
    }
    EmSetDieOn(em->emset_no);
}

// Counts a kill in the chapter and game kill counters (results screen).
void EmSetDieCnt(cEm* pEm)
{
    pG->c_kill_cnt++;
    pG->g_kill_cnt++;
}

// Room change: clears the "set" bit of every list entry so the new room can create its enemies.
void EmSetRoomInit()
{
    int i;

    for (i = 0; i < 256; i++) {
        EM_LIST* d = &pG->Em_list[i];

        d->be_flag &= ~2;
    }
}

// Every 30 frames: intended to delete waiting list enemies; the loop body is empty in the
// shipped game.
void EmListWaitDelete()
{
    int i;

    if (pG->Frame_cnt % 30 != 0) {
        return;
    }
    for (i = 0; i < 256; i++) {
    }
}
